from tkinter import *
import tkinter as ttk
from tkinter import messagebox
import pymysql
pymysql.install_as_MySQLdb()  



window= Tk()
window.title("User Account Report")
window.configure(bg='#BDEDFF')
p1=PhotoImage(file='logos.png')
window.iconphoto(False,p1)

p1=PhotoImage(file='logos.png')
window.iconphoto(False,p1)

lbl=Label(window,text="User Account Report",fg="#000080" ,bg='#157DEC',font=("arial",30,'bold'),bd=6,relief=GROOVE)
lbl.place(x=1,y=1,relwidth=1)

tree = Treeview(window)

#con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

cursor = con.cursor()

tree["columns"] = ("one", "two", "three")
tree.column("one", width=100)
tree.column("two", width=100)
tree.column("three", width=100)


cursor.execute("SELECT * FROM usermaster")

cpt = 0 
tree.insert('', 'end', values=(row[0], row[1], row[2]))
cpt += 1 # increment the ID
tree.pack()
window.geometry("800x650+200+100")
window.mainloop()
