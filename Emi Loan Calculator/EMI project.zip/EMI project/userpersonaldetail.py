from tkinter import *
from tkinter import messagebox
import pymysql
pymysql.install_as_MySQLdb()
from PIL import Image,ImageTk 

def first():
    #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
    con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")


    cursor = con.cursor()
    cursor.execute("select * from userpersonaldetail limit 1")
    rows = cursor.fetchall()
    for row in rows:
        userid.insert(0, row[0])
        username.insert(0, row[1])
        dateofbirth.insert(0, row[2])
        address.insert(0, row[3])
        phone.insert(0, row[4])
        mobile.insert(0, row[5])
        email.insert(0, row[6])
    con.close()
    
def previous():
    #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
    con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

    cursor = con.cursor()
    cursor.execute("select * from userpersonaldetail limit 1")
    rows = cursor.fetchall()
    for row in rows:
        userid.insert(0, row[0])
        username.insert(0, row[1])
        dateofbirth.insert(0, row[2])
        address.insert(0, row[3])
        phone.insert(0, row[4])
        mobile.insert(0, row[5])
        email.insert(0, row[6])
    con.close()

def next1():
    #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
    con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

    cursor = con.cursor()
    cursor.execute("select * from userpersonaldetail limit 1")
    rows = cursor.fetchall()
    for row in rows:
        userid.insert(0, row[0])
        username.insert(0, row[1])
        dateofbirth.insert(0, row[2])
        address.insert(0, row[3])
        phone.insert(0, row[4])
        mobile.insert(0, row[5])
        email.insert(0, row[6])
    con.close()
def last():
    #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
    con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

    cursor = con.cursor()
    cursor.execute("select * from userpersonaldetail order by userid desc limit 1")
    rows = cursor.fetchall()
    for row in rows:
        userid.insert(0, row[0])
        username.insert(0, row[1])
        dateofbirth.insert(0, row[2])
        address.insert(0, row[3])
        phone.insert(0, row[4])
        mobile.insert(0, row[5])
        email.insert(0, row[6])
    con.close()

def save():
    uid = userid.get()
    uname = username.get()
    dob = dateofbirth.get()
    adrs = address.get()
    phon = phone.get()
    mob = mobile.get()
    em = email.get()
    if(uid =="" and uname =="" and adrs==""):
        messagebox.showinfo("Insert Status","All Fields are required")
    else:
        #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
        con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

        cursor = con.cursor()
        cursor.execute("insert into userpersonaldetail values('"+ uid +"','"+ uname +"','"+ dob +"','"+ adrs +"','"+ phon +"','"+ mob +"','"+ em +"')")
        cursor.execute("commit")

        userid.delete(0, 'end')
        username.delete(0, 'end')
        dateofbirth.delete(0, 'end')
        address.delete(0, 'end')
        phone.delete(0, 'end')
        mobile.delete(0, 'end')
        email.delete(0, 'end')
        messagebox.showinfo("Insert Status","Insert successfully")
        con.close()

def update():
    uid = userid.get()
    uname = username.get()
    dob = dateofbirth.get()
    adrs = address.get()
    phon = phone.get()
    mob = mobile.get()
    em = email.get()
    if(uid =="" and uname =="" and adrs== ""):
        messagebox.showinfo("update Status","All Fields are required")
    else:
        #con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
        con = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="Shreya@1234", db="emiloancalculator")

        cursor = con.cursor()
        cursor.execute("update userpersonaldetail set  username ='"+ uname +"',dateofbirth ='"+ dob +"', address ='"+ adrs +"',phone='"+ phon +"', mobile='"+ mob +"', email='"+ em +"' where userid='"+ uid +"'")
        #cursor.execute ("update userpersonaldetail set username= '%s', dateofbirth= '%s', address= '%s',phone= '%s', mobile= '%s', email= '%s' where userid = '%s'" %(uid,uname,dob,adrs,phon,mob,em))
        cursor.execute("commit")

        userid.delete(0, 'end')
        username.delete(0, 'end')
        dateofbirth.delete(0, 'end')
        address.delete(0, 'end')
        phone.delete(0, 'end')
        mobile.delete(0, 'end')
        email.delete(0, 'end')
        messagebox.showinfo("Update Status","Update successfully")
        con.close()


window=Tk()
window.title("User Personal Detail")
window.configure(bg='#9646B7')
p1=PhotoImage(file='logos.png')
window.iconphoto(False,p1)

lbl12=Label(window,text="User Personal Detail",fg="white" ,bg='#292F68',font=("arial",30,'bold'),bd=6,relief=GROOVE)

lbl1=Label(window,text="User Id",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl2=Label(window,text="User Name",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl3=Label(window,text="Date Of Birth",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl4=Label(window,text="Address",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl5=Label(window,text="Phone",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl6=Label(window,text="Mobile",fg="white",bg='#9646B7',font=('arial',14,'bold'))
lbl7=Label(window,text="email",fg="white",bg='#9646B7',font=('arial',14,'bold'))


userid=Entry(window,bd=4,width=10,bg='#F0F8FF',font=('arial',14))
username=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
dateofbirth=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
address=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
phone=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
mobile=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
email=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))


firsticon=PhotoImage(file='button_first.png')
previousicon=PhotoImage(file='buttons_17.png')
next1icon=PhotoImage(file='buttons_12.png')
lasticon=PhotoImage(file='button_last.png')
addicon=PhotoImage(file='buttons_11.png')
updateicon=PhotoImage(file='arrow_clockwise.png')
saveicon=PhotoImage(file='tick.png')
cancelicon=PhotoImage(file='delete.png')

first=Button(window,compound=LEFT,width=100,image=firsticon,text="First",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=first)
previous=Button(window,compound=LEFT,width=100,image=previousicon,text="Previous",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=previous)
next1=Button(window,compound=LEFT,width=100,image=next1icon,text="Next",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=next1)
last=Button(window,compound=LEFT,width=100,image=lasticon,text="Last",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=last)
add=Button(window,compound=LEFT,width=100,image=addicon,text="Add",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=save)
update=Button(window,compound=LEFT,width=100,image=updateicon,text="Update",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=update)
save=Button(window,compound=LEFT,width=100,image=saveicon,text="Save",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=save)
cancel=Button(window,compound=LEFT,width=100,image=cancelicon,text="Cancel",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=window.quit)


lbl12.place(x=1,y=1,relwidth=1)
        
lbl1.place(x=80,y=100)
userid.place(x=280,y=100)
        
lbl2.place(x=80,y=160)
username.place(x=280,y=160)
          
lbl3.place(x=80,y=220)
dateofbirth.place(x=280,y=220)
        
lbl4.place(x=80,y=280)
address.place(x=280,y=280)

lbl5.place(x=80,y=340)
phone.place(x=280,y=340)

lbl6.place(x=80,y=400)
mobile.place(x=280,y=400)

lbl7.place(x=80,y=460)
email.place(x=280,y=460)

first.place(x=100,y=530)
previous.place(x=250,y=530)
next1.place(x=400,y=530)
last.place(x=550,y=530)
add.place(x=100,y=580)
update.place(x=250,y=580)
save.place(x=400,y=580)
cancel.place(x=550,y=580)

image=Image.open("user.png")
image = image.resize((150, 250), Image.ANTIALIAS)
photo=ImageTk.PhotoImage(image)
lbl=Label(window,image=photo,bg='#9646B7')
lbl.place(x=600,y=150)

window.geometry("800x650+200+100")
window.mainloop()

