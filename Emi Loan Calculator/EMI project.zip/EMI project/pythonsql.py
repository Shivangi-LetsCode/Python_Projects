#Python - MySQL connectivity
import mysql.connector
#open a database connection
#db = mysql.connector.connect("localhost","root","root","pyprojectdb")
db = mysql.connector.connect(host="127.0.0.1", port=3307, user="root", passwd="Shreya@1234", db="pyprojectdb")


#prepare the cursor object using cursor() method
cursor = db.cursor()

#execute SQL query using execute()...
cursor.execute("select * from product")

#fetch a single row using fetchone()
data = cursor.fetchone()
print(data)

#disconnect from server
db.close()
